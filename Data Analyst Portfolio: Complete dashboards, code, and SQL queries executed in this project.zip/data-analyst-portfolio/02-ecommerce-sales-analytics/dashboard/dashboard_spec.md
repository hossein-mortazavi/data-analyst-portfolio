# Power BI dashboard specification

## Page 1 — Sales overview
KPI cards: Net Sales, Estimated Gross Profit, Order Lines, Return Line Rate.
Charts: monthly sales trend, sales by category, sales by region.

## Page 2 — Product performance
Top products by net sales and gross profit; category comparison; order status breakdown.

## Data model
A single fact table is sufficient for this starter project. For an expanded version, create Date, Product, Customer, and Region dimension tables.
