import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data/orders.csv", parse_dates=["order_date"])
df["gross_line_sales"] = df["quantity"] * df["unit_price"]
df["net_sales"] = df["gross_line_sales"].where(df["order_status"].eq("Completed"), 0)
df["estimated_gross_profit"] = (df["quantity"] * (df["unit_price"] - df["unit_cost"])).where(df["order_status"].eq("Completed"), 0)

print("Rows:", len(df))
print("Duplicate order IDs:", df["order_id"].duplicated().sum())
print("Missing values:\n", df.isna().sum())
print(f"Net sales: ${df['net_sales'].sum():,.2f}")
print(f"Estimated gross profit: ${df['estimated_gross_profit'].sum():,.2f}")
print(f"Return line rate: {df['order_status'].eq('Returned').mean():.1%}")

category = df.groupby("product_category", as_index=False).agg(
    net_sales=("net_sales", "sum"),
    estimated_gross_profit=("estimated_gross_profit", "sum"),
    order_lines=("order_id", "count")
).sort_values("net_sales", ascending=False)
print("\nCategory performance:\n", category)

monthly = df.set_index("order_date").resample("MS").agg(
    net_sales=("net_sales", "sum"),
    estimated_gross_profit=("estimated_gross_profit", "sum")
)
print("\nMonthly performance:\n", monthly.tail())
