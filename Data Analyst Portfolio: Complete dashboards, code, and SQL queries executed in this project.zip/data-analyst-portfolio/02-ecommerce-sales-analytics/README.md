# 02 — E-commerce Sales Analytics

## Business scenario
An online retailer wants to understand sales, product mix, regional performance, and profitability.

## Questions
1. What are gross sales, net sales, and gross profit?
2. Which categories and products contribute most to revenue and profit?
3. Which regions have the strongest performance?
4. How do sales change month by month?
5. How much revenue is affected by returns and cancellations?

## Data
`data/orders.csv` contains synthetic order-line records. Each row represents one order line. `order_status` distinguishes Completed, Returned, and Cancelled.

## Metric definitions
- Gross sales = quantity × unit price for completed and returned orders.
- Net sales = quantity × unit price for completed orders only.
- Estimated gross profit = quantity × (unit price − unit cost) for completed orders only.
- Return rate = returned order lines / all order lines. This is a line-level rate, not an order-level rate.

## Run
From this folder: `python analysis.py`

## Dashboard
Executive KPIs: Net Sales, Estimated Gross Profit, Completed Order Lines, Return Line Rate.  
Visuals: monthly net sales, profit by category, sales by region, top products, order status distribution.

## Caveat
This dataset has one row per order line and does not include shipping, tax, discounts, or customer acquisition costs. Profit is therefore an estimated product gross profit, not net business profit.
