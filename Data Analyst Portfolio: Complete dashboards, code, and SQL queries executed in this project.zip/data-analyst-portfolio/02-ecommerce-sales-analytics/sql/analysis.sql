-- Net sales and estimated gross profit by category
SELECT
    product_category,
    SUM(CASE WHEN order_status = 'Completed' THEN quantity * unit_price ELSE 0 END) AS net_sales,
    SUM(CASE WHEN order_status = 'Completed' THEN quantity * (unit_price - unit_cost) ELSE 0 END) AS estimated_gross_profit
FROM orders
GROUP BY product_category
ORDER BY net_sales DESC;

-- Monthly net sales
SELECT
    DATE_TRUNC('month', order_date) AS sales_month,
    SUM(CASE WHEN order_status = 'Completed' THEN quantity * unit_price ELSE 0 END) AS net_sales
FROM orders
GROUP BY DATE_TRUNC('month', order_date)
ORDER BY sales_month;

-- Performance by region
SELECT
    region,
    COUNT(*) AS order_lines,
    SUM(CASE WHEN order_status = 'Completed' THEN quantity * unit_price ELSE 0 END) AS net_sales
FROM orders
GROUP BY region
ORDER BY net_sales DESC;

-- Return and cancellation line counts
SELECT order_status, COUNT(*) AS order_lines
FROM orders
GROUP BY order_status;
