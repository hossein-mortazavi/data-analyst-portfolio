-- Customer-level RFM base table (PostgreSQL)
WITH customer_rfm AS (
    SELECT
        customer_id,
        MAX(transaction_date) AS last_purchase_date,
        COUNT(DISTINCT transaction_id) AS frequency,
        SUM(amount) AS monetary
    FROM transactions
    GROUP BY customer_id
)
SELECT
    customer_id,
    CURRENT_DATE - last_purchase_date AS recency_days,
    frequency,
    monetary
FROM customer_rfm
ORDER BY monetary DESC;
