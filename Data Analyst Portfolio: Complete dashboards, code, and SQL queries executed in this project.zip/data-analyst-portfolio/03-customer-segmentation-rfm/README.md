# 03 — Customer Segmentation & RFM Analysis

## Business scenario
A retailer wants to prioritize customer relationships using purchasing behavior.

## Questions
1. Who purchased most recently?
2. Who purchases most frequently?
3. Which customers generate the highest monetary value?
4. Which customer groups may be suitable for loyalty, upsell, or reactivation campaigns?

## Data
`data/transactions.csv` contains synthetic transaction records with transaction ID, customer ID, date, and transaction amount.

## Method
RFM stands for Recency, Frequency, and Monetary:
- Recency: days since the customer's latest transaction, relative to the analysis date.
- Frequency: number of transactions.
- Monetary: total transaction amount.

Customers are scored from 1 to 5 using quintiles. Segment labels are illustrative rules and should be validated against business context.

## Run
From this folder: `python analysis.py`

## Recommendations framework
- Champions: recognize and retain.
- Loyal Customers: reward and cross-sell.
- Potential Loyalists: encourage repeat purchases.
- At Risk: investigate inactivity and test win-back messaging.
- Hibernating: use low-cost reactivation experiments.

## Caveat
RFM is a behavioral segmentation method, not a predictive churn model. It does not explain why customers behave a certain way.
