import pandas as pd

df = pd.read_csv("data/transactions.csv", parse_dates=["transaction_date"])
analysis_date = df["transaction_date"].max() + pd.Timedelta(days=1)

rfm = df.groupby("customer_id").agg(
    last_purchase=("transaction_date", "max"),
    frequency=("transaction_id", "nunique"),
    monetary=("amount", "sum")
).reset_index()
rfm["recency"] = (analysis_date - rfm["last_purchase"]).dt.days

# Quintile scoring: high frequency/monetary is good; low recency is good.
rfm["R"] = pd.qcut(rfm["recency"].rank(method="first"), 5, labels=[5,4,3,2,1]).astype(int)
rfm["F"] = pd.qcut(rfm["frequency"].rank(method="first"), 5, labels=[1,2,3,4,5]).astype(int)
rfm["M"] = pd.qcut(rfm["monetary"].rank(method="first"), 5, labels=[1,2,3,4,5]).astype(int)
rfm["rfm_score"] = rfm[["R","F","M"]].sum(axis=1)

def segment(row):
    if row["R"] >= 4 and row["F"] >= 4 and row["M"] >= 4:
        return "Champions"
    if row["R"] >= 3 and row["F"] >= 4:
        return "Loyal Customers"
    if row["R"] >= 4 and row["F"] <= 2:
        return "Potential Loyalists"
    if row["R"] <= 2 and row["F"] >= 3:
        return "At Risk"
    return "Hibernating"

rfm["segment"] = rfm.apply(segment, axis=1)
print(rfm.groupby("segment").agg(customers=("customer_id","count"), avg_monetary=("monetary","mean"), avg_recency=("recency","mean")).sort_values("customers", ascending=False))
rfm.to_csv("rfm_customer_segments.csv", index=False)
