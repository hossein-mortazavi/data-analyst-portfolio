# Data Analyst Portfolio

A collection of five end-to-end data analytics projects demonstrating business problem-solving with SQL, Python, pandas, and Power BI.

> **Data notice:** The datasets in this repository are synthetic and generated for portfolio demonstration. They do not represent real companies, customers, or financial results. All findings should be interpreted as demonstrations of analytical methods, not claims about real business performance.

## Projects

| # | Project | Business questions | Core tools |
|---|---|---|---|
| 01 | SaaS Business & Product Analytics | How are revenue, churn, retention, and product usage changing? | SQL, Python, Power BI |
| 02 | E-commerce Sales Analytics | Which products, categories, and regions drive sales and profit? | SQL, Python, Power BI |
| 03 | Customer Segmentation & RFM | Which customers are most valuable and who may need reactivation? | SQL, Python, pandas |
| 04 | Marketing Performance Analytics | Which channels generate efficient conversions and returns? | SQL, Python, Power BI |
| 05 | Financial & Business Performance | How do revenue, expenses, and profit change over time? | SQL, Python, Power BI |

## Repository structure

```text
data-analyst-portfolio/
├── README.md
├── requirements.txt
├── 01-saas-business-analytics/
├── 02-ecommerce-sales-analytics/
├── 03-customer-segmentation-rfm/
├── 04-marketing-performance-analytics/
└── 05-financial-business-analytics/
```

Each project contains a project brief, a synthetic dataset, SQL analysis, a Python analysis script, and a dashboard specification.

## How to use

1. Clone or download this repository.
2. Install the dependencies: `pip install -r requirements.txt`
3. Open a project folder and read its `README.md`.
4. Run the Python script from that project folder, for example:
   `python analysis.py`
5. Load the CSV files into PostgreSQL or another SQL database and run the queries in the `sql/` folder.
6. Build the dashboard in Power BI using the included dashboard guide.

## Skills demonstrated

- Data cleaning and validation
- Exploratory data analysis (EDA)
- SQL joins, aggregations, CTEs, and window functions
- KPI definition and business metric analysis
- Customer, product, and channel analysis
- Segmentation and cohort-style analysis
- Data visualization and business storytelling
- Translating findings into actionable recommendations

## Important analytical principles

- Revenue, profit, conversion rate, churn, and ROI are defined explicitly in each project.
- Missing values and duplicate records should be checked before analysis.
- Ratios should be calculated from aggregated numerators and denominators, not by averaging row-level percentages.
- Correlation does not prove causation.
- Synthetic data can validate an analytical workflow, but it cannot establish real-world business conclusions.

## Author

**Hossein Mortazavi**  
Data Analyst | Business Intelligence | SQL | Python | Power BI

Portfolio focus: Transforming Data into Business Value.
