# 04 — Marketing Performance Analytics

## Business scenario
A marketing team needs to compare campaign channels based on reach, traffic, lead generation, customer acquisition, and attributed revenue.

## Questions
1. Which channels generate the most clicks, leads, and acquired customers?
2. Which channels have the lowest cost per lead (CPL) and customer acquisition cost (CAC)?
3. What are click-through rate (CTR), lead conversion rate, and attributed ROAS?
4. Are high-volume channels also efficient?

## Data
`data/campaigns.csv` contains synthetic campaign-level performance records.

## Metric definitions
- CTR = clicks / impressions.
- Lead conversion rate = leads / clicks.
- CPL = spend / leads.
- CAC = spend / customers acquired.
- Attributed ROAS = attributed revenue / spend.

Guard against division by zero. ROAS is based on synthetic attributed revenue and is not incremental lift.

## Run
From this folder: `python analysis.py`

## Dashboard
KPI cards: Spend, Clicks, Leads, Customers Acquired, Attributed Revenue, ROAS.  
Charts: spend and revenue by channel, CAC by channel, CTR and lead conversion rate, campaign-level scatter plot.

## Caveat
Attribution is provided as a field in the synthetic data. The project does not prove that campaigns caused the attributed revenue.
