-- Aggregate channel metrics before calculating ratios
SELECT
    channel,
    SUM(spend) AS spend,
    SUM(impressions) AS impressions,
    SUM(clicks) AS clicks,
    SUM(leads) AS leads,
    SUM(customers_acquired) AS customers_acquired,
    SUM(attributed_revenue) AS attributed_revenue,
    SUM(clicks)::numeric / NULLIF(SUM(impressions), 0) AS ctr,
    SUM(leads)::numeric / NULLIF(SUM(clicks), 0) AS lead_conversion_rate,
    SUM(spend) / NULLIF(SUM(leads), 0) AS cost_per_lead,
    SUM(spend) / NULLIF(SUM(customers_acquired), 0) AS cac,
    SUM(attributed_revenue) / NULLIF(SUM(spend), 0) AS attributed_roas
FROM campaigns
GROUP BY channel
ORDER BY cac;
