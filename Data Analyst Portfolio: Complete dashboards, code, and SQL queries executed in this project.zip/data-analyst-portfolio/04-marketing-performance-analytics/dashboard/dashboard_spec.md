# Power BI dashboard specification

## Page 1 — Channel overview
Cards: Spend, Leads, Acquired Customers, Attributed Revenue, CAC, ROAS.
Charts: spend vs attributed revenue by channel; leads by channel; CAC comparison.

## Page 2 — Campaign details
Campaign table with channel, impressions, clicks, leads, acquired customers, spend, CAC, and ROAS. Add date and channel slicers.

Calculate ratios from aggregated totals in DAX rather than averaging campaign-level ratios.
