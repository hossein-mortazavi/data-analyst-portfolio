import pandas as pd

df = pd.read_csv("data/campaigns.csv", parse_dates=["date"])
df["ctr"] = df["clicks"].div(df["impressions"].replace(0, pd.NA))
df["lead_conversion_rate"] = df["leads"].div(df["clicks"].replace(0, pd.NA))
df["cpl"] = df["spend"].div(df["leads"].replace(0, pd.NA))
df["cac"] = df["spend"].div(df["customers_acquired"].replace(0, pd.NA))
df["roas"] = df["attributed_revenue"].div(df["spend"].replace(0, pd.NA))

summary = df.groupby("channel", as_index=False).agg(
    spend=("spend","sum"),
    impressions=("impressions","sum"),
    clicks=("clicks","sum"),
    leads=("leads","sum"),
    customers=("customers_acquired","sum"),
    attributed_revenue=("attributed_revenue","sum")
)
summary["ctr"] = summary["clicks"] / summary["impressions"]
summary["lead_conversion_rate"] = summary["leads"] / summary["clicks"].replace(0, pd.NA)
summary["cpl"] = summary["spend"] / summary["leads"].replace(0, pd.NA)
summary["cac"] = summary["spend"] / summary["customers"].replace(0, pd.NA)
summary["roas"] = summary["attributed_revenue"] / summary["spend"].replace(0, pd.NA)

print(summary.sort_values("cac"))
summary.to_csv("channel_performance_summary.csv", index=False)
