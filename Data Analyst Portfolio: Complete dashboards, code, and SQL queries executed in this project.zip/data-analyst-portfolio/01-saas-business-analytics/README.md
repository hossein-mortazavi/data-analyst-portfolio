# 01 — SaaS Business & Product Analytics

## Business scenario
A subscription software business wants to understand recurring revenue, customer churn, plan mix, and product engagement.

## Questions
1. How many customers are active and churned?
2. Which subscription plans contribute most to monthly recurring revenue (MRR)?
3. How does churn vary by plan and country?
4. Are customers with lower product engagement associated with higher churn?
5. Which customer groups should the business investigate first?

## Data
- `data/customers.csv`: one row per customer; includes plan, monthly fee, signup date, country, and status.
- `data/product_usage.csv`: monthly product activity by customer.

All records are synthetic. The customer status is a simplified snapshot; do not interpret it as a complete historical subscription ledger.

## Metrics
- **MRR (snapshot):** sum of monthly fees for customers whose status is Active.
- **Customer churn rate (snapshot):** churned customers / all customers.
- **Average sessions:** total sessions / customer-month records.
- **Engagement:** key actions and sessions are activity indicators, not proof of product value.

## Run
From this folder: `python analysis.py`

Load both CSV files into PostgreSQL, then run `sql/analysis.sql`.

## Recommended dashboard
Cards: Active Customers, Snapshot MRR, Snapshot Churn Rate, Average Sessions.  
Charts: MRR by plan, customer status by plan, churn by country, monthly product usage trend, engagement by plan.

## Decision-oriented output
End the analysis with 2–3 recommendations supported by the actual computed results. Avoid assuming that low engagement causes churn; investigate timing and other factors.
