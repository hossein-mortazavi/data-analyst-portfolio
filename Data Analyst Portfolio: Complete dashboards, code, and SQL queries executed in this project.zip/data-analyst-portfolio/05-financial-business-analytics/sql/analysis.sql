WITH monthly AS (
    SELECT
        month,
        revenue,
        cost_of_goods_sold,
        payroll_expense,
        marketing_expense,
        operating_expense,
        revenue - cost_of_goods_sold AS gross_profit,
        payroll_expense + marketing_expense + operating_expense AS total_operating_expenses
    FROM monthly_financials
)
SELECT
    month,
    revenue,
    gross_profit,
    gross_profit / NULLIF(revenue, 0) AS gross_margin,
    total_operating_expenses,
    gross_profit - total_operating_expenses AS operating_profit
FROM monthly
ORDER BY month;
