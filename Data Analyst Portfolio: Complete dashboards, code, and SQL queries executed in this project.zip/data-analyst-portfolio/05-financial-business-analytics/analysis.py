import pandas as pd

df = pd.read_csv("data/monthly_financials.csv", parse_dates=["month"])
df["gross_profit"] = df["revenue"] - df["cost_of_goods_sold"]
df["gross_margin"] = df["gross_profit"] / df["revenue"].replace(0, pd.NA)
expense_cols = ["payroll_expense","marketing_expense","operating_expense"]
df["total_operating_expenses"] = df[expense_cols].sum(axis=1)
df["operating_profit"] = df["gross_profit"] - df["total_operating_expenses"]
df["revenue_mom_change_pct"] = df["revenue"].pct_change()

print(df.tail(12).to_string(index=False))
print("\nTotals:")
print(df[["revenue","gross_profit","total_operating_expenses","operating_profit"]].sum())
print("\nAverage gross margin:", f"{df['gross_margin'].mean():.1%}")
