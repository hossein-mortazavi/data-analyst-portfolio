# 05 — Financial & Business Performance Analytics

## Business scenario
A growing business wants a clear view of monthly revenue, cost structure, gross profit, operating expenses, and operating profit.

## Questions
1. Is revenue increasing or decreasing?
2. How are cost of goods sold and operating expenses changing?
3. What are gross profit, gross margin, and operating profit?
4. Which expense categories account for the largest share of costs?
5. Which months show unusual changes that deserve investigation?

## Data
`data/monthly_financials.csv` contains 24 months of synthetic monthly financial data.

## Metric definitions
- Gross profit = revenue − cost of goods sold.
- Gross margin = gross profit / revenue.
- Total operating expenses = payroll + marketing + operating expenses.
- Operating profit (simplified) = gross profit − total operating expenses.

This simplified model excludes tax, interest, depreciation, amortization, and other possible accounting items.

## Run
From this folder: `python analysis.py`

## Dashboard
Cards: Revenue, Gross Profit, Gross Margin, Operating Expenses, Operating Profit.  
Charts: monthly revenue and profit trend, expense composition, gross margin trend, month-over-month revenue change.

## Caveat
The data is synthetic and simplified for analytical demonstration, not for accounting, audit, or investment decisions.
