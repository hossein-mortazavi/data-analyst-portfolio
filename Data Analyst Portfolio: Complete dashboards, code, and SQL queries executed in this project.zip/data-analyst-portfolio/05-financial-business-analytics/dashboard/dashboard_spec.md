# Power BI dashboard specification

## Page 1 — Financial overview
Cards: Total Revenue, Gross Profit, Gross Margin, Operating Expenses, Operating Profit.
Charts: revenue and operating profit by month; gross margin trend; expense category breakdown.

## Page 2 — Cost analysis
Compare payroll, marketing, and operating expenses over time. Add month slicer and month-over-month change indicators.

Document the simplified operating-profit definition on the report page.
